import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  
  // Habilitar CORS es vital para que Vue (puerto 5173) hable con Nest (puerto 3000)
  app.enableCors(); 

  // CAMBIO CLAVE: Agregamos '0.0.0.0' para que sea accesible desde fuera del contenedor
  const port = process.env.PORT ?? 3000;
  await app.listen(port, '0.0.0.0');
  
  console.log(`🏨 Backend del Hotel corriendo en: http://localhost:${port}`);
}
bootstrap();
