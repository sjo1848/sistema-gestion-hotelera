export class CreateRoomDto {}
